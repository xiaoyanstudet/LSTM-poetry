from __future__ import annotations

import csv
import json
import shutil
import subprocess
from pathlib import Path
from textwrap import dedent
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm, mm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.platypus import (
    Image,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / "闫冠霖-LSTM实验"
DOC_DIR = PACKAGE / "01_实验报告"
PPT_DIR = PACKAGE / "02_实验PPT"
CODE_DIR = PACKAGE / "03_代码版本"
FIG_DIR = PACKAGE / "04_结果图表"
SAMPLE_DIR = PACKAGE / "05_生成样例"
DATA_DIR = PACKAGE / "06_数据与模型说明"
SOURCE_DIR = PACKAGE / "07_原始资料"

BUNDLED_NODE = Path.home() / ".cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
PRESENTATION_BUILD = (
    Path.home()
    / ".codex/plugins/cache/openai-primary-runtime/presentations/26.521.10419/skills/presentations/scripts/build_artifact_deck.mjs"
)

METRICS = [
    {
        "version": "Baseline LSTM",
        "code": "main.py + function.py + classmodel.py",
        "model": "2-layer LSTM",
        "best_epoch": 79,
        "train_loss": 4.619173160483258,
        "val_loss": 4.916936813383201,
        "perplexity": 136.58359071494775,
        "format_accuracy": 1.0,
        "distinct_1": 0.359375,
        "distinct_2": 0.8467741935483871,
        "sample": "poem_7_epoch_079.txt",
        "summary": "验证集 loss 最低，客观指标最好；生成内容存在重复和套话。",
    },
    {
        "version": "Attention-LSTM v1",
        "code": "improved_train.py",
        "model": "LSTM + causal self-attention",
        "best_epoch": 11,
        "train_loss": 4.115380195637596,
        "val_loss": 5.00259271031377,
        "perplexity": 148.7984506897849,
        "format_accuracy": 1.0,
        "distinct_1": 0.515625,
        "distinct_2": 0.9193548387096774,
        "sample": "poem_7_improved_epoch_011.txt",
        "summary": "生成流畅度和多样性提升，但较早出现过拟合，验证 loss 高于 baseline。",
    },
    {
        "version": "Attention-LSTM v2",
        "code": "improved_train.py",
        "model": "Smaller Attention-LSTM + stronger regularization",
        "best_epoch": 30,
        "train_loss": 4.592970742307817,
        "val_loss": 5.367086561244272,
        "perplexity": 214.23778890494404,
        "format_accuracy": 1.0,
        "distinct_1": 0.45703125,
        "distinct_2": 0.7701612903225806,
        "sample": "poem_7_improved_v2_epoch_030.txt",
        "summary": "格式稳定，样例较完整；正则偏强导致欠拟合，客观指标退化。",
    },
]

VERSION_SNAPSHOTS = [
    ("62e4bf3", "版本1_初始一键训练代码"),
    ("057e387", "版本2_50轮训练与过拟合观察"),
    ("833c231", "版本3_加入改动记录文档"),
    ("7186537", "版本4_OpenCC简繁规范化"),
]

CODE_FILES = [
    ".gitignore",
    "main.py",
    "function.py",
    "classmodel.py",
    "improved_train.py",
    "requirements.txt",
    "start_training.command",
    "sync_to_github.command",
    "CHANGELOG.md",
]

FIGURES = [
    "data/figures/training_metrics_7.png",
    "data/figures/training_metrics_7_improved.png",
    "data/figures/training_metrics_7_improved_v2.png",
]

SAMPLES = [
    "data/samples/poem_7_epoch_079.txt",
    "data/samples/poem_7_improved_epoch_011.txt",
    "data/samples/poem_7_improved_v2_epoch_030.txt",
    "data/samples/poem_7_improved_v2_epoch_038.txt",
]


def ensure_dirs() -> None:
    for path in [DOC_DIR, PPT_DIR, CODE_DIR, FIG_DIR, SAMPLE_DIR, DATA_DIR, SOURCE_DIR]:
        path.mkdir(parents=True, exist_ok=True)


def copy_if_exists(src: Path, dst: Path) -> bool:
    if not src.exists():
        return False
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return True


def run_git_show(commit: str, filename: str) -> bytes | None:
    result = subprocess.run(
        ["git", "show", f"{commit}:{filename}"],
        cwd=ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    return result.stdout if result.returncode == 0 else None


def export_code_versions() -> None:
    for commit, folder_name in VERSION_SNAPSHOTS:
        out_dir = CODE_DIR / folder_name
        out_dir.mkdir(parents=True, exist_ok=True)
        for filename in CODE_FILES:
            content = run_git_show(commit, filename)
            if content is None:
                continue
            target = out_dir / filename
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)

    current_dir = CODE_DIR / "版本5_当前Attention_LSTM改进版"
    current_dir.mkdir(parents=True, exist_ok=True)
    for filename in CODE_FILES:
        copy_if_exists(ROOT / filename, current_dir / filename)

    version_notes = CODE_DIR / "代码版本索引.md"
    version_notes.write_text(
        dedent(
            """\
            # 代码版本索引

            本目录按实验迭代过程整理代码快照，前四个版本来自本地 git 提交，最后一个版本来自当前工作区。

            | 目录 | 来源 | 说明 |
            | --- | --- | --- |
            | 版本1_初始一键训练代码 | git commit 62e4bf3 | 自动下载数据、MPS/CPU 自适应、checkpoint、基础评测与训练曲线。 |
            | 版本2_50轮训练与过拟合观察 | git commit 057e387 | 记录 50 轮训练后 loss 继续下降但生成质量有限的问题。 |
            | 版本3_加入改动记录文档 | git commit 833c231 | 加入 CHANGELOG，用于记录每轮代码修改原因、内容和结果。 |
            | 版本4_OpenCC简繁规范化 | git commit 7186537 | 加入 OpenCC 简体化流程，减少繁体字和格式不规范问题。 |
            | 版本5_当前Attention_LSTM改进版 | 当前工作区 | 新增 improved_train.py，包含 Attention-LSTM v1/v2 结构和生成策略改进。 |

            说明：历史版本不一定都包含 improved_train.py，因为该文件是在后续模型改进阶段新增的。
            """
        ),
        encoding="utf-8",
    )


def export_results() -> None:
    for figure in FIGURES:
        copy_if_exists(ROOT / figure, FIG_DIR / Path(figure).name)

    for sample in SAMPLES:
        copy_if_exists(ROOT / sample, SAMPLE_DIR / Path(sample).name)

    for filename in ["data/process_meta.json", "data/poem_7.txt", "data/poem_5.txt"]:
        copy_if_exists(ROOT / filename, DATA_DIR / Path(filename).name)

    copy_if_exists(ROOT / "实验3：自动写诗实验指导书.pdf", SOURCE_DIR / "实验3：自动写诗实验指导书.pdf")
    copy_if_exists(ROOT / "lstm自动写诗.pptx", SOURCE_DIR / "原始_lstm自动写诗.pptx")

    metrics_json = DATA_DIR / "metrics_summary.json"
    metrics_csv = DATA_DIR / "metrics_summary.csv"
    metrics_json.write_text(json.dumps(METRICS, ensure_ascii=False, indent=2), encoding="utf-8")
    with metrics_csv.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(METRICS[0].keys()))
        writer.writeheader()
        writer.writerows(METRICS)

    combined = ["# 生成样例汇总\n"]
    for item in METRICS:
        sample_path = SAMPLE_DIR / item["sample"]
        if sample_path.exists():
            combined.append(f"## {item['version']}（best epoch {item['best_epoch']}）\n")
            combined.append("```text\n")
            combined.append(sample_path.read_text(encoding="utf-8"))
            combined.append("\n```\n")
    (SAMPLE_DIR / "生成样例汇总.md").write_text("\n".join(combined), encoding="utf-8")

    (DATA_DIR / "数据与模型说明.md").write_text(
        dedent(
            """\
            # 数据与模型说明

            ## 数据

            - 数据来源：chinese-poetry 项目中的《全唐诗》JSON 文件。
            - 本地 raw 数据目录：项目根目录下的 tangshi/，大小约 25 MB。
            - 预处理后七言诗：poem_7.txt，共 10638 首。
            - 预处理后五言诗：poem_5.txt，共 3912 首。
            - 已启用 OpenCC 简体化，减少繁体字进入训练与生成结果。

            ## 模型权重

            本提交包没有复制 .pt checkpoint 权重文件。原因是项目的 data/checkpoints/ 目录约 13 GB，
            完整复制后不适合压缩提交。报告、PPT、训练曲线、样例、指标表和代码版本已经足够说明实验过程。

            如老师要求提交权重，可以在原项目中复制以下最佳模型：

            - data/checkpoints/poem_7_best.pt：Baseline LSTM 最佳模型，约 75 MB。
            - data/checkpoints/poem_7_improved_best.pt：Attention-LSTM v1 最佳模型，约 99 MB。
            - data/checkpoints/poem_7_improved_v2_best.pt：Attention-LSTM v2 最佳模型，约 65 MB。
            """
        ),
        encoding="utf-8",
    )


def p(text: str, style: ParagraphStyle) -> Paragraph:
    return Paragraph(escape(text).replace("\n", "<br/>"), style)


def scaled_image(path: Path, max_width: float, max_height: float) -> Image:
    reader = ImageReader(str(path))
    width, height = reader.getSize()
    scale = min(max_width / width, max_height / height)
    return Image(str(path), width * scale, height * scale)


def build_report_pdf() -> None:
    pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="CNTitle",
            parent=styles["Title"],
            fontName="STSong-Light",
            fontSize=24,
            leading=32,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#12324A"),
            spaceAfter=12,
            wordWrap="CJK",
        )
    )
    styles.add(
        ParagraphStyle(
            name="CNSubtitle",
            parent=styles["Normal"],
            fontName="STSong-Light",
            fontSize=12,
            leading=20,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#4B5563"),
            spaceAfter=8,
            wordWrap="CJK",
        )
    )
    styles.add(
        ParagraphStyle(
            name="CNHeading1",
            parent=styles["Heading1"],
            fontName="STSong-Light",
            fontSize=16,
            leading=24,
            textColor=colors.HexColor("#12324A"),
            spaceBefore=14,
            spaceAfter=8,
            wordWrap="CJK",
        )
    )
    styles.add(
        ParagraphStyle(
            name="CNHeading2",
            parent=styles["Heading2"],
            fontName="STSong-Light",
            fontSize=13,
            leading=20,
            textColor=colors.HexColor("#0F766E"),
            spaceBefore=10,
            spaceAfter=6,
            wordWrap="CJK",
        )
    )
    styles.add(
        ParagraphStyle(
            name="CNBody",
            parent=styles["Normal"],
            fontName="STSong-Light",
            fontSize=10.5,
            leading=17,
            firstLineIndent=18,
            alignment=TA_LEFT,
            wordWrap="CJK",
        )
    )
    styles.add(
        ParagraphStyle(
            name="CNList",
            parent=styles["Normal"],
            fontName="STSong-Light",
            fontSize=10.2,
            leading=16,
            leftIndent=12,
            wordWrap="CJK",
        )
    )
    styles.add(
        ParagraphStyle(
            name="CNSmall",
            parent=styles["Normal"],
            fontName="STSong-Light",
            fontSize=8.8,
            leading=13,
            wordWrap="CJK",
        )
    )

    report_path = DOC_DIR / "闫冠霖-LSTM实验报告.pdf"
    doc = SimpleDocTemplate(
        str(report_path),
        pagesize=A4,
        rightMargin=1.8 * cm,
        leftMargin=1.8 * cm,
        topMargin=1.8 * cm,
        bottomMargin=1.8 * cm,
        title="闫冠霖-LSTM自动写诗实验报告",
    )

    story = []
    story.append(p("LSTM 自动写诗实验报告", styles["CNTitle"]))
    story.append(p("学生：闫冠霖    生成日期：2026-05-23", styles["CNSubtitle"]))
    story.append(p("实验主题：基于 PyTorch LSTM 的唐诗生成、MPS 加速、训练恢复、评测可视化与模型改进", styles["CNSubtitle"]))
    story.append(Spacer(1, 10 * mm))

    story.append(p("一、实验目的", styles["CNHeading1"]))
    story.append(
        p(
            "本实验围绕中文古诗自动生成任务展开，目标是在给定唐诗语料的基础上训练一个能够生成七言绝句格式文本的神经网络模型。"
            "在原始训练代码基础上，实验进一步完成了数据自动下载、Mac M 系列芯片 MPS 加速、checkpoint 断点续训、训练指标可视化、"
            "OpenCC 简繁规范化、生成格式约束以及 Attention-LSTM 结构改进。",
            styles["CNBody"],
        )
    )

    story.append(p("二、数据集与预处理", styles["CNHeading1"]))
    data_table = Table(
        [
            ["项目", "内容"],
            ["数据来源", "chinese-poetry 项目《全唐诗》JSON 文件"],
            ["raw 数据大小", "约 25 MB"],
            ["预处理后七言诗", "10638 首"],
            ["预处理后五言诗", "3912 首"],
            ["文本规范化", "启用 OpenCC，将繁体字转换为简体字"],
            ["格式处理", "筛选五言/七言诗，生成时强制逗号、句号位置"],
        ],
        colWidths=[3.5 * cm, 12 * cm],
    )
    data_table.setStyle(table_style())
    story.append(data_table)

    story.append(p("三、代码迭代过程", styles["CNHeading1"]))
    version_table = Table(
        [
            ["版本", "核心改动", "目的"],
            ["版本1", "一键训练、自动下载、MPS 设备选择、checkpoint、训练曲线", "让代码能在 MacBook M4 上直接运行"],
            ["版本2", "观察 50 轮训练结果与过拟合迹象", "判断是否继续增加 epoch"],
            ["版本3", "新增 CHANGELOG.md", "记录每次改动原因、内容和实验结果"],
            ["版本4", "接入 OpenCC 简体化", "减少繁体字和格式不规范问题"],
            ["版本5", "新增 improved_train.py，加入 Attention-LSTM 和采样策略改进", "改善生成流畅度、多样性和格式控制"],
        ],
        colWidths=[2.0 * cm, 8.0 * cm, 5.5 * cm],
    )
    version_table.setStyle(table_style(font_size=8.6))
    story.append(version_table)

    story.append(p("四、模型与训练设置", styles["CNHeading1"]))
    for line in [
        "Baseline LSTM：Embedding 128，Hidden 512，2 层 LSTM，Dropout 0.3，学习率 3e-4。",
        "Attention-LSTM v1：在 LSTM 输出上加入因果 self-attention，并加入 top-k/top-p、重复惩罚、no-repeat ngram 生成策略。",
        "Attention-LSTM v2：减小 hidden 维度到 384，提高 dropout 和 weight decay，并加入 label smoothing，试图缓解过拟合。",
        "训练设备：优先使用 torch.backends.mps，对 MacBook M 系列芯片进行加速；不支持 MPS 时自动回退 CPU。",
        "训练机制：支持 latest/best checkpoint、异常中断后自动恢复、早停、每轮样例生成和训练指标图片输出。",
    ]:
        story.append(p("• " + line, styles["CNList"]))

    story.append(p("五、实验结果对比", styles["CNHeading1"]))
    rows = [["模型版本", "最佳 epoch", "train loss", "val loss", "PPL", "格式准确率", "Distinct-1", "Distinct-2"]]
    for item in METRICS:
        rows.append(
            [
                item["version"],
                str(item["best_epoch"]),
                f"{item['train_loss']:.3f}",
                f"{item['val_loss']:.3f}",
                f"{item['perplexity']:.1f}",
                f"{item['format_accuracy']:.2f}",
                f"{item['distinct_1']:.3f}",
                f"{item['distinct_2']:.3f}",
            ]
        )
    metrics_table = Table(rows, colWidths=[3.5 * cm, 2.0 * cm, 2.0 * cm, 2.0 * cm, 1.8 * cm, 2.0 * cm, 1.8 * cm, 1.8 * cm])
    metrics_table.setStyle(table_style(font_size=8.3))
    story.append(metrics_table)
    story.append(
        p(
            "从客观指标看，Baseline LSTM 的验证 loss 和困惑度最低，是本轮实验中的最佳泛化模型。"
            "Attention-LSTM v1 的 Distinct 指标最高，说明生成文本更加多样，但训练较早过拟合。"
            "Attention-LSTM v2 通过更强正则化缓解了过拟合，但验证 loss 明显升高，表现为欠拟合。",
            styles["CNBody"],
        )
    )

    story.append(p("六、训练曲线可视化", styles["CNHeading1"]))
    for figure, caption in [
        ("training_metrics_7.png", "Baseline LSTM 训练曲线"),
        ("training_metrics_7_improved.png", "Attention-LSTM v1 训练曲线"),
        ("training_metrics_7_improved_v2.png", "Attention-LSTM v2 训练曲线"),
    ]:
        figure_path = FIG_DIR / figure
        if figure_path.exists():
            story.append(p(caption, styles["CNHeading2"]))
            story.append(scaled_image(figure_path, max_width=16 * cm, max_height=8.5 * cm))
            story.append(Spacer(1, 4 * mm))

    story.append(PageBreak())
    story.append(p("七、生成样例分析", styles["CNHeading1"]))
    sample_intro = (
        "以下选取各模型最佳 epoch 附近的生成样例。Baseline LSTM 的字词频率更贴近训练集，因此验证 loss 更低，"
        "但内容容易出现“春风、花落、何处”等高频模式重复。Attention-LSTM 的句子衔接更自然，部分样例可读性更强，"
        "但会出现罕见字或语义空泛的问题。"
    )
    story.append(p(sample_intro, styles["CNBody"]))
    for item in METRICS:
        sample_path = SAMPLE_DIR / item["sample"]
        if not sample_path.exists():
            continue
        text = "\n".join(sample_path.read_text(encoding="utf-8").splitlines()[:12])
        story.append(p(item["version"], styles["CNHeading2"]))
        story.append(p(text, styles["CNSmall"]))

    story.append(p("八、结论", styles["CNHeading1"]))
    for line in [
        "自动写诗模型不能只看 loss，还需要结合格式准确率、困惑度、多样性指标和人工主观质量评价。",
        "OpenCC 简体化和格式约束是必要改动，它们直接解决了繁体字和标点格式不符合七言绝句的问题。",
        "继续单纯增加 epoch 的收益有限：当训练 loss 下降但验证 loss 不改善时，主要问题已经转向模型结构、采样策略和语料质量。",
        "在本次实验中，Baseline LSTM 是客观指标最优模型；Attention-LSTM v1/v2 证明结构改进能改善部分样例，但也会带来过拟合或欠拟合风险。",
        "后续可尝试更大语料、韵律/平仄约束、Beam Search 重排序，或使用 Transformer 类模型进一步提升生成质量。",
    ]:
        story.append(p("• " + line, styles["CNList"]))

    story.append(p("九、提交文件说明", styles["CNHeading1"]))
    story.append(
        p(
            "提交包包含 PDF 实验报告、PPT 汇报文件、按版本整理的代码、训练曲线、生成样例、指标表、预处理数据和原始实验指导书。"
            "考虑到 checkpoint 目录约 13 GB，本提交包未复制全部 .pt 权重文件，只在数据与模型说明中列出最佳模型路径。",
            styles["CNBody"],
        )
    )

    doc.build(story, onFirstPage=page_footer, onLaterPages=page_footer)

    markdown = DOC_DIR / "闫冠霖-LSTM实验报告.md"
    markdown.write_text(report_markdown(), encoding="utf-8")


def table_style(font_size: float = 9.2) -> TableStyle:
    return TableStyle(
        [
            ("FONTNAME", (0, 0), (-1, -1), "STSong-Light"),
            ("FONTSIZE", (0, 0), (-1, -1), font_size),
            ("LEADING", (0, 0), (-1, -1), font_size + 4),
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E6F0F3")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#12324A")),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#C9D4DA")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ]
    )


def page_footer(canvas, doc) -> None:
    canvas.saveState()
    canvas.setFont("STSong-Light", 8)
    canvas.setFillColor(colors.HexColor("#6B7280"))
    canvas.drawRightString(A4[0] - 1.8 * cm, 1.1 * cm, f"闫冠霖 LSTM 自动写诗实验报告  |  第 {doc.page} 页")
    canvas.restoreState()


def report_markdown() -> str:
    lines = [
        "# LSTM 自动写诗实验报告",
        "",
        "学生：闫冠霖",
        "生成日期：2026-05-23",
        "",
        "## 核心结论",
        "",
        "- Baseline LSTM 的验证 loss 和 perplexity 最低，是客观指标最优模型。",
        "- Attention-LSTM v1 的 distinct 指标更好，样例多样性更高，但更早过拟合。",
        "- Attention-LSTM v2 正则化更强，格式稳定，但本轮表现欠拟合。",
        "- OpenCC 简体化和格式约束有效解决了繁体字、标点和七言绝句格式问题。",
        "",
        "## 指标汇总",
        "",
        "| 模型 | 最佳epoch | train loss | val loss | PPL | 格式准确率 | Distinct-1 | Distinct-2 |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for item in METRICS:
        lines.append(
            f"| {item['version']} | {item['best_epoch']} | {item['train_loss']:.3f} | "
            f"{item['val_loss']:.3f} | {item['perplexity']:.1f} | {item['format_accuracy']:.2f} | "
            f"{item['distinct_1']:.3f} | {item['distinct_2']:.3f} |"
        )
    lines.extend(
        [
            "",
            "## 文件说明",
            "",
            "- `01_实验报告/`：PDF 报告和 Markdown 源文件。",
            "- `02_实验PPT/`：实验汇报 PPTX。",
            "- `03_代码版本/`：按实验迭代整理的代码快照。",
            "- `04_结果图表/`：训练曲线图片。",
            "- `05_生成样例/`：各模型生成结果。",
            "- `06_数据与模型说明/`：指标表、预处理数据和模型权重说明。",
        ]
    )
    return "\n".join(lines) + "\n"


def js_string(value: str | Path) -> str:
    return json.dumps(str(value), ensure_ascii=False)


def slide_theme_source() -> str:
    return dedent(
        """\
        export const T = {
          ink: "#102333",
          muted: "#5B6773",
          light: "#F5F8FA",
          line: "#D8E1E7",
          teal: "#0F766E",
          blue: "#246B9E",
          gold: "#B7791F",
          red: "#B45353",
          green: "#2F855A",
          white: "#FFFFFF",
          titleFont: "PingFang SC",
          bodyFont: "PingFang SC"
        };

        export function base(slide, ctx, section = "") {
          ctx.addShape(slide, { x: 0, y: 0, width: ctx.W, height: ctx.H, fill: T.white, line: ctx.line("#00000000", 0) });
          ctx.addShape(slide, { x: 0, y: 0, width: 16, height: ctx.H, fill: T.teal, line: ctx.line("#00000000", 0) });
          ctx.addText(slide, {
            text: section, x: 52, y: 30, width: 420, height: 28,
            fontSize: 17, color: T.teal, bold: true, face: T.bodyFont,
          });
          ctx.addText(slide, {
            text: "闫冠霖 · LSTM 自动写诗实验", x: 52, y: 666, width: 520, height: 28,
            fontSize: 14, color: "#6B7280", face: T.bodyFont,
          });
          ctx.addText(slide, {
            text: "2026-05-23", x: 1060, y: 666, width: 150, height: 28,
            fontSize: 14, color: "#6B7280", align: "right", face: T.bodyFont,
          });
        }

        export function title(slide, ctx, text, subtitle = "") {
          ctx.addText(slide, {
            text, x: 52, y: 80, width: 760, height: 70,
            fontSize: 36, color: T.ink, bold: true, face: T.titleFont,
          });
          if (subtitle) {
            ctx.addText(slide, {
              text: subtitle, x: 54, y: 152, width: 760, height: 56,
              fontSize: 18, color: T.muted, face: T.bodyFont,
            });
          }
        }

        export function bullets(slide, ctx, items, x, y, width, height, fontSize = 24) {
          ctx.addText(slide, {
            text: items.map((item) => "• " + item).join("\\n"),
            x, y, width, height,
            fontSize, color: T.ink, face: T.bodyFont,
            insets: { left: 2, right: 12, top: 4, bottom: 4 },
          });
        }

        export function card(slide, ctx, x, y, width, height, label, value, note, color = T.teal) {
          ctx.addShape(slide, {
            x, y, width, height, fill: "#FFFFFF",
            line: ctx.line("#D7E2E8", 1),
          });
          ctx.addShape(slide, { x, y, width: 8, height, fill: color, line: ctx.line("#00000000", 0) });
          ctx.addText(slide, { text: label, x: x + 24, y: y + 18, width: width - 40, height: 28, fontSize: 15, color: T.muted, face: T.bodyFont });
          ctx.addText(slide, { text: value, x: x + 24, y: y + 50, width: width - 40, height: 42, fontSize: 29, color, bold: true, face: T.titleFont });
          ctx.addText(slide, { text: note, x: x + 24, y: y + 98, width: width - 40, height: height - 106, fontSize: 14, color: T.ink, face: T.bodyFont });
        }

        export function pill(slide, ctx, text, x, y, color) {
          ctx.addShape(slide, { x, y, width: 188, height: 40, fill: color, line: ctx.line("#00000000", 0) });
          ctx.addText(slide, { text, x: x + 12, y: y + 8, width: 164, height: 24, fontSize: 15, color: T.white, bold: true, align: "center", face: T.bodyFont });
        }

        export function barChart(slide, ctx, titleText, bars, x, y, width, height, maxValue, lowerBetter = true) {
          ctx.addText(slide, { text: titleText, x, y: y - 34, width, height: 28, fontSize: 18, color: T.ink, bold: true, face: T.bodyFont });
          ctx.addShape(slide, { x, y: y + height, width, height: 1, fill: T.line, line: ctx.line("#00000000", 0) });
          const gap = 36;
          const barW = (width - gap * (bars.length + 1)) / bars.length;
          bars.forEach((bar, i) => {
            const h = Math.max(4, (bar.value / maxValue) * height);
            const bx = x + gap + i * (barW + gap);
            const by = y + height - h;
            ctx.addShape(slide, { x: bx, y: by, width: barW, height: h, fill: bar.color, line: ctx.line("#00000000", 0) });
            ctx.addText(slide, { text: bar.value.toFixed(bar.value > 20 ? 1 : 3), x: bx - 8, y: by - 28, width: barW + 16, height: 22, fontSize: 13, color: T.ink, align: "center", face: T.bodyFont });
            ctx.addText(slide, { text: bar.name, x: bx - 18, y: y + height + 12, width: barW + 36, height: 42, fontSize: 13, color: T.muted, align: "center", face: T.bodyFont });
          });
          ctx.addText(slide, {
            text: lowerBetter ? "越低越好" : "越高越好",
            x: x + width - 96, y: y - 32, width: 92, height: 22,
            fontSize: 13, color: T.muted, align: "right", face: T.bodyFont,
          });
        }
        """
    )


def build_slide_modules(workspace: Path) -> None:
    slides = workspace / "slides"
    slides.mkdir(parents=True, exist_ok=True)
    (workspace / "theme.mjs").write_text(slide_theme_source(), encoding="utf-8")

    fig1 = FIG_DIR / "training_metrics_7.png"
    fig2 = FIG_DIR / "training_metrics_7_improved.png"
    fig3 = FIG_DIR / "training_metrics_7_improved_v2.png"
    sample_v2 = (SAMPLE_DIR / "poem_7_improved_v2_epoch_030.txt").read_text(encoding="utf-8").splitlines()
    sample_text = "\n".join(sample_v2[5:9])

    slide_sources = [
        f"""\
        import {{ base, title, bullets, card, T }} from "../theme.mjs";
        export async function slide01(presentation, ctx) {{
          const slide = presentation.slides.add();
          base(slide, ctx, "实验汇报");
          title(slide, ctx, "LSTM 自动写诗实验", "唐诗语料 · Mac MPS 加速 · 训练恢复 · 评测可视化 · 模型改进");
          card(slide, ctx, 64, 250, 330, 150, "数据规模", "10638", "七言诗训练样本；同时保留 3912 首五言诗预处理结果。", T.teal);
          card(slide, ctx, 430, 250, 330, 150, "最佳客观模型", "Baseline", "best epoch 79，val loss 4.917，perplexity 136.6。", T.blue);
          card(slide, ctx, 796, 250, 330, 150, "改进方向", "Attention", "新增 causal self-attention 与更严格的生成策略。", T.gold);
          bullets(slide, ctx, ["目标：生成符合七言绝句格式的中文诗句", "重点：一键训练、断点恢复、MPS 加速、曲线与样例输出", "结论：复杂结构不一定带来更低 loss，采样策略和数据质量同样关键"], 76, 470, 1060, 130, 21);
          return slide;
        }}
        """,
        """\
        import { base, title, bullets, pill, T } from "../theme.mjs";
        export async function slide02(presentation, ctx) {
          const slide = presentation.slides.add();
          base(slide, ctx, "任务与数据");
          title(slide, ctx, "从原始代码到可复现实验", "先解决能稳定跑起来，再讨论模型效果。");
          pill(slide, ctx, "自动下载数据", 90, 245, T.teal);
          pill(slide, ctx, "OpenCC 简体化", 330, 245, T.blue);
          pill(slide, ctx, "五言/七言筛选", 570, 245, T.gold);
          pill(slide, ctx, "训练集/验证集", 810, 245, T.green);
          ctx.addShape(slide, { x: 178, y: 265, width: 150, height: 2, fill: "#CBD5E1", line: ctx.line("#00000000", 0) });
          ctx.addShape(slide, { x: 418, y: 265, width: 150, height: 2, fill: "#CBD5E1", line: ctx.line("#00000000", 0) });
          ctx.addShape(slide, { x: 658, y: 265, width: 150, height: 2, fill: "#CBD5E1", line: ctx.line("#00000000", 0) });
          bullets(slide, ctx, [
            "raw 数据：chinese-poetry《全唐诗》JSON 文件，本地约 25 MB",
            "预处理：保留五言和七言诗，七言诗作为本次主要训练对象",
            "规范化：OpenCC 将繁体转简体，生成阶段强制标点位置",
            "结果：七言诗 10638 首，五言诗 3912 首"
          ], 92, 370, 1030, 170, 22);
          return slide;
        }
        """,
        """\
        import { base, title, bullets, card, T } from "../theme.mjs";
        export async function slide03(presentation, ctx) {
          const slide = presentation.slides.add();
          base(slide, ctx, "工程化改动");
          title(slide, ctx, "一键训练需要的不只是模型", "把容易中断、容易配置错的部分都放进训练脚本。");
          card(slide, ctx, 74, 236, 300, 185, "设备", "MPS", "自动检测 torch.backends.mps；不可用时回退 CPU。", T.teal);
          card(slide, ctx, 410, 236, 300, 185, "续训", "latest/best", "保存 latest 与 best checkpoint，中断后从 latest 恢复。", T.blue);
          card(slide, ctx, 746, 236, 300, 185, "评测", "loss + PPL", "每轮输出 loss、perplexity、格式准确率、distinct 指标和样例。", T.gold);
          bullets(slide, ctx, ["训练入口：main.py 运行 baseline；improved_train.py 运行改进模型", "训练输出：data/figures 曲线图，data/samples 样例，data/checkpoints 权重", "提交包未复制 13 GB 全量 checkpoint，只保留指标、图表和说明"], 88, 470, 1020, 116, 20);
          return slide;
        }
        """,
        """\
        import { base, title, bullets, card, T } from "../theme.mjs";
        export async function slide04(presentation, ctx) {
          const slide = presentation.slides.add();
          base(slide, ctx, "模型版本");
          title(slide, ctx, "三组核心实验", "同一数据集上比较基础 LSTM 与 Attention-LSTM。");
          card(slide, ctx, 70, 230, 320, 230, "Baseline LSTM", "epoch 79", "2 层 LSTM，hidden 512。验证 loss 最低，但生成样例重复较明显。", T.blue);
          card(slide, ctx, 430, 230, 320, 230, "Attention-LSTM v1", "epoch 11", "加入 causal self-attention。样例更流畅，distinct 更高，但过拟合更早。", T.teal);
          card(slide, ctx, 790, 230, 320, 230, "Attention-LSTM v2", "epoch 30", "减小模型并加强正则。格式稳定，但客观指标变差，表现为欠拟合。", T.gold);
          bullets(slide, ctx, ["判断标准：不仅看训练 loss，还看验证 loss、perplexity、多样性、格式和人工可读性"], 80, 510, 1050, 64, 21);
          return slide;
        }
        """,
        """\
        import { base, title, barChart, T } from "../theme.mjs";
        export async function slide05(presentation, ctx) {
          const slide = presentation.slides.add();
          base(slide, ctx, "指标对比");
          title(slide, ctx, "Baseline 指标最好，Attention 更多样", "验证 loss 与困惑度越低越好，distinct 越高说明生成更不重复。");
          const bars = [
            { name: "Baseline", value: 4.917, color: T.blue },
            { name: "Attn v1", value: 5.003, color: T.teal },
            { name: "Attn v2", value: 5.367, color: T.gold },
          ];
          const ppl = [
            { name: "Baseline", value: 136.6, color: T.blue },
            { name: "Attn v1", value: 148.8, color: T.teal },
            { name: "Attn v2", value: 214.2, color: T.gold },
          ];
          const distinct = [
            { name: "Baseline", value: 0.359, color: T.blue },
            { name: "Attn v1", value: 0.516, color: T.teal },
            { name: "Attn v2", value: 0.457, color: T.gold },
          ];
          barChart(slide, ctx, "Validation loss", bars, 78, 270, 330, 220, 5.6, true);
          barChart(slide, ctx, "Perplexity", ppl, 470, 270, 330, 220, 230, true);
          barChart(slide, ctx, "Distinct-1", distinct, 862, 270, 330, 220, 0.6, false);
          ctx.addText(slide, { text: "格式准确率三组均为 1.00，说明 OpenCC + 格式约束已经解决主要格式问题。", x: 92, y: 575, width: 1040, height: 42, fontSize: 20, color: T.ink, face: T.bodyFont });
          return slide;
        }
        """,
        f"""\
        import {{ base, title, T }} from "../theme.mjs";
        export async function slide06(presentation, ctx) {{
          const slide = presentation.slides.add();
          base(slide, ctx, "训练曲线");
          title(slide, ctx, "Baseline LSTM：loss 继续下降，但文本重复", "best epoch 79，val loss 4.917。");
          await ctx.addImage(slide, {{ path: {js_string(fig1)}, x: 86, y: 212, width: 760, height: 330, fit: "contain", alt: "baseline training metrics" }});
          ctx.addText(slide, {{ text: "观察\\n• 验证 loss 仍在缓慢下降\\n• PPL 最低，泛化指标最好\\n• 生成句式有高频词重复\\n• 单纯增加 epoch 不是主要改进方向", x: 880, y: 230, width: 300, height: 270, fontSize: 21, color: T.ink, face: T.bodyFont }});
          return slide;
        }}
        """,
        f"""\
        import {{ base, title, T }} from "../theme.mjs";
        export async function slide07(presentation, ctx) {{
          const slide = presentation.slides.add();
          base(slide, ctx, "训练曲线");
          title(slide, ctx, "Attention-LSTM：结构改进带来新问题", "v1 更流畅但过拟合早，v2 正则更强但欠拟合。");
          await ctx.addImage(slide, {{ path: {js_string(fig2)}, x: 70, y: 222, width: 520, height: 300, fit: "contain", alt: "attention v1 metrics" }});
          await ctx.addImage(slide, {{ path: {js_string(fig3)}, x: 646, y: 222, width: 520, height: 300, fit: "contain", alt: "attention v2 metrics" }});
          ctx.addText(slide, {{ text: "v1：best epoch 11，distinct-1 最高；v2：best epoch 30，格式稳定但 val loss 升高。", x: 95, y: 560, width: 1050, height: 44, fontSize: 19, color: T.ink, align: "center", face: T.bodyFont }});
          return slide;
        }}
        """,
        f"""\
        import {{ base, title, T }} from "../theme.mjs";
        export async function slide08(presentation, ctx) {{
          const slide = presentation.slides.add();
          base(slide, ctx, "生成样例");
          title(slide, ctx, "样例可读性提升，但语义仍偏模板化", "Attention-LSTM v2 best epoch 30 片段。");
          ctx.addShape(slide, {{ x: 90, y: 220, width: 1020, height: 310, fill: "#F5F8FA", line: ctx.line("#D8E1E7", 1) }});
          ctx.addText(slide, {{ text: {js_string(sample_text)}, x: 125, y: 250, width: 950, height: 250, fontSize: 28, color: T.ink, face: T.bodyFont }});
          ctx.addText(slide, {{ text: "评价：格式符合七言绝句；局部句子通顺；但“春风、何处、万里”等意象复用明显，深层语义和主题一致性仍不足。", x: 100, y: 565, width: 1000, height: 58, fontSize: 19, color: T.muted, face: T.bodyFont }});
          return slide;
        }}
        """,
        """\
        import { base, title, bullets, T } from "../theme.mjs";
        export async function slide09(presentation, ctx) {
          const slide = presentation.slides.add();
          base(slide, ctx, "实验结论");
          title(slide, ctx, "模型能力评价应多指标结合", "自动写诗不是分类任务，不能只用 loss 做最终判断。");
          bullets(slide, ctx, [
            "客观指标：train/val loss、perplexity、格式准确率、distinct-1/2",
            "语言质量：是否通顺，是否少重复，是否有完整意象和主题一致性",
            "格式质量：是否七言、标点位置是否正确、是否出现繁体或异常符号",
            "模型比较：baseline 泛化最好，attention 样例更自然但稳定性不足",
            "后续方向：韵律约束、重排序、更多语料或 Transformer 结构"
          ], 98, 235, 1030, 310, 25);
          return slide;
        }
        """,
        """\
        import { base, title, bullets, card, T } from "../theme.mjs";
        export async function slide10(presentation, ctx) {
          const slide = presentation.slides.add();
          base(slide, ctx, "提交包");
          title(slide, ctx, "提交文件已按实验过程整理", "报告、PPT、代码版本、图表、样例和数据说明集中在同一文件夹。");
          card(slide, ctx, 78, 225, 310, 170, "01 / 02", "报告 + PPT", "PDF 实验报告与可编辑 PowerPoint 汇报。", T.teal);
          card(slide, ctx, 430, 225, 310, 170, "03", "代码版本", "git 历史版本与当前 Attention-LSTM 改进版。", T.blue);
          card(slide, ctx, 782, 225, 310, 170, "04 / 05 / 06", "结果材料", "训练曲线、生成样例、指标表、数据与模型说明。", T.gold);
          bullets(slide, ctx, ["未复制 13 GB 全量 checkpoint，避免提交包过大", "如需提交模型权重，可按说明单独复制三个 best.pt 文件", "重新训练后可再次运行 build_submission_package.py 更新材料"], 92, 470, 1020, 130, 21);
          return slide;
        }
        """,
    ]

    for index, source in enumerate(slide_sources, start=1):
        (slides / f"slide-{index:02d}.mjs").write_text(dedent(source), encoding="utf-8")


def build_pptx() -> None:
    workspace = PPT_DIR / "PPT构建预览"
    build_slide_modules(workspace)
    out_path = PPT_DIR / "闫冠霖-LSTM实验汇报.pptx"
    preview_dir = workspace / "preview"
    layout_dir = workspace / "layout"
    cmd = [
        str(BUNDLED_NODE),
        str(PRESENTATION_BUILD),
        "--workspace",
        str(workspace),
        "--slides-dir",
        str(workspace / "slides"),
        "--out",
        str(out_path),
        "--preview-dir",
        str(preview_dir),
        "--layout-dir",
        str(layout_dir),
        "--slide-count",
        "10",
        "--scale",
        "1",
    ]
    subprocess.run(cmd, cwd=ROOT, check=True)
    (PPT_DIR / "PPT预览图片目录.txt").write_text(
        f"预览图片由 artifact-tool 生成，位置：\n{preview_dir}\n", encoding="utf-8"
    )


def write_readme() -> None:
    copy_if_exists(ROOT / "build_submission_package.py", PACKAGE / "build_submission_package.py")
    (PACKAGE / "README_提交说明.txt").write_text(
        dedent(
            f"""\
            闫冠霖-LSTM实验 提交包说明

            主要文件：
            1. 01_实验报告/闫冠霖-LSTM实验报告.pdf
            2. 02_实验PPT/闫冠霖-LSTM实验汇报.pptx
            3. 03_代码版本/：按实验迭代整理的各版本代码
            4. 04_结果图表/：训练曲线图片
            5. 05_生成样例/：各模型生成样例
            6. 06_数据与模型说明/：指标表、预处理数据、模型权重说明
            7. 07_原始资料/：实验指导书和原始 PPT

            注意：
            data/checkpoints/ 全目录约 13 GB，本提交包没有复制完整 checkpoint。
            如果老师要求提交模型权重，请参考 06_数据与模型说明/数据与模型说明.md。
            """
        ),
        encoding="utf-8",
    )


def main() -> None:
    ensure_dirs()
    export_code_versions()
    export_results()
    build_report_pdf()
    build_pptx()
    write_readme()
    print(f"提交包已生成：{PACKAGE}")


if __name__ == "__main__":
    main()
