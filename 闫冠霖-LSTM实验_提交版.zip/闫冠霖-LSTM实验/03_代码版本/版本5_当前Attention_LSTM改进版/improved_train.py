import argparse
import math
import os
import random
from dataclasses import asdict, dataclass
from pathlib import Path

os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")

import torch
from torch import nn
from torch.utils.data import DataLoader, random_split

import classmodel
import function


IMPROVED_MODEL_VERSION = "causal_v2"
STARTER_CHARS = "春秋山水月风花云江夜白青清寒孤长落天一客君人日雨雪松竹"


@dataclass
class ImprovedTrainConfig:
    run_name: str = "improved_v2"
    raw_dir: str = "tangshi"
    data_dir: str = "data"
    poem_type: int = 7
    batch_size: int = 64
    epochs: int = 80
    lr: float = 2e-4
    embedding_dim: int = 128
    hidden_dim: int = 384
    num_layers: int = 2
    attention_heads: int = 6
    dropout: float = 0.4
    weight_decay: float = 2e-4
    label_smoothing: float = 0.05
    val_ratio: float = 0.1
    eval_batches: int = 30
    sample_count: int = 8
    checkpoint_every_batches: int = 200
    log_interval: int = 60
    early_stopping_patience: int = 8
    early_stopping_min_delta: float = 1e-3
    simplify_text: bool = True
    constrain_format: bool = True
    max_files: int = 0
    download_retries: int = 3
    strict_download: bool = False
    force_download: bool = False
    force_process: bool = False
    resume: bool = True
    device: str = "auto"
    seed: int = 42
    start_words: str = "湖光秋月两相和"
    temperature: float = 0.75
    top_k: int = 8
    top_p: float = 0.82
    repetition_penalty: float = 1.08
    no_repeat_ngram: int = 3
    start_top_n: int = 200
    max_candidate_rank: int = 1800


class AttentionPoemLstm(nn.Module):
    """LSTM plus self-attention for short poem generation.

    The LSTM learns local character order. The attention block lets each
    position look back over the whole generated line context before predicting
    the next character.
    """

    def __init__(
        self,
        vocab_size,
        embedding_dim=128,
        hidden_dim=512,
        num_layers=2,
        attention_heads=8,
        dropout=0.3,
        label_smoothing=0.0,
    ):
        super().__init__()
        if hidden_dim % attention_heads != 0:
            raise ValueError("hidden_dim must be divisible by attention_heads")

        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        self.lstm = nn.LSTM(
            input_size=embedding_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )
        self.attention = nn.MultiheadAttention(
            embed_dim=hidden_dim,
            num_heads=attention_heads,
            dropout=dropout,
            batch_first=True,
        )
        self.attn_norm = nn.LayerNorm(hidden_dim)
        self.ffn = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 2, hidden_dim),
        )
        self.ffn_norm = nn.LayerNorm(hidden_dim)
        self.dropout = nn.Dropout(dropout)
        self.linear = nn.Linear(hidden_dim, vocab_size)
        self.loss = nn.CrossEntropyLoss(label_smoothing=label_smoothing)

    def forward(self, x, hidden=None):
        embeds = self.embedding(x)
        output, hidden = self.lstm(embeds, hidden)
        seq_len = output.shape[1]
        causal_mask = torch.triu(
            torch.ones(seq_len, seq_len, dtype=torch.bool, device=output.device),
            diagonal=1,
        )
        attn_output, _ = self.attention(
            output,
            output,
            output,
            attn_mask=causal_mask,
            need_weights=False,
        )
        output = self.attn_norm(output + self.dropout(attn_output))
        output = self.ffn_norm(output + self.dropout(self.ffn(output)))
        logits = self.linear(output)
        return logits.reshape(-1, logits.shape[-1]), hidden


def set_seed(seed):
    random.seed(seed)
    torch.manual_seed(seed)


def empty_history():
    return {
        "train_loss": [],
        "val_loss": [],
        "perplexity": [],
        "format_accuracy": [],
        "distinct_1": [],
        "distinct_2": [],
        "best_val_loss": None,
        "best_epoch": 0,
        "epochs_without_improvement": 0,
    }


def normalize_history(history=None):
    result = empty_history()
    if history:
        result.update(history)
    return result


def save_checkpoint(path, model, optimizer, next_epoch, global_step, config, word_to_index, index_to_word, history):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model_type": "attention_lstm",
            "model_version": IMPROVED_MODEL_VERSION,
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "next_epoch": next_epoch,
            "global_step": global_step,
            "config": asdict(config),
            "word_to_index": word_to_index,
            "index_to_word": index_to_word,
            "history": history,
        },
        path,
    )


def load_checkpoint(path, model, optimizer, device, word_to_index, index_to_word):
    try:
        checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        checkpoint = torch.load(path, map_location="cpu")

    if checkpoint.get("model_type") != "attention_lstm" or checkpoint.get("model_version") != IMPROVED_MODEL_VERSION:
        print(f"Checkpoint is not an {IMPROVED_MODEL_VERSION} attention_lstm checkpoint; start fresh.")
        return 0, 0, empty_history()
    if checkpoint.get("word_to_index") != word_to_index or checkpoint.get("index_to_word") != index_to_word:
        print("Checkpoint vocab differs from current data; start fresh.")
        return 0, 0, empty_history()

    try:
        model.load_state_dict(checkpoint["model_state"])
        optimizer.load_state_dict(checkpoint["optimizer_state"])
    except RuntimeError as exc:
        print(f"Checkpoint shape differs from current model; start fresh. {exc}")
        return 0, 0, empty_history()

    for state in optimizer.state.values():
        for key, value in state.items():
            if torch.is_tensor(value):
                state[key] = value.to(device)

    next_epoch = int(checkpoint.get("next_epoch", 0))
    global_step = int(checkpoint.get("global_step", 0))
    history = normalize_history(checkpoint.get("history"))
    print(f"Resumed improved model from {path}: next_epoch={next_epoch + 1}, global_step={global_step}")
    return next_epoch, global_step, history


def evaluate(model, loader, device, max_batches=30):
    model.eval()
    total_loss = 0.0
    total_tokens = 0
    with torch.no_grad():
        for batch_idx, (inputs, labels) in enumerate(loader):
            if max_batches and batch_idx >= max_batches:
                break
            inputs = inputs.to(device)
            labels = labels.to(device)
            outputs, _ = model(inputs)
            flat_labels = labels.reshape(-1)
            loss = model.loss(outputs, flat_labels)
            total_loss += float(loss.detach().cpu()) * flat_labels.numel()
            total_tokens += flat_labels.numel()
    if total_tokens == 0:
        return {"val_loss": 0.0, "perplexity": 0.0}
    val_loss = total_loss / total_tokens
    return {"val_loss": val_loss, "perplexity": math.exp(min(val_loss, 20.0))}


def format_marks(poem_type):
    if poem_type == 5:
        return {5: "，", 11: "。", 17: "，", 23: "。"}
    return {7: "，", 15: "。", 23: "，", 31: "。"}


def banned_ngram_ids(ids, n):
    if n <= 1 or len(ids) < n - 1:
        return set()
    prefix = tuple(ids[-(n - 1) :])
    banned = set()
    for i in range(len(ids) - n + 1):
        if tuple(ids[i : i + n - 1]) == prefix:
            banned.add(ids[i + n - 1])
    return banned


def sample_next_id(
    logits,
    previous_ids,
    temperature=0.85,
    top_k=12,
    top_p=0.88,
    repetition_penalty=1.18,
    no_repeat_ngram=3,
    banned_ids=None,
    max_candidate_rank=0,
):
    logits = logits.detach().to("cpu").clone()
    banned = set(banned_ids or set()) | banned_ngram_ids(previous_ids, no_repeat_ngram)
    if max_candidate_rank and max_candidate_rank > 0 and max_candidate_rank < logits.shape[-1]:
        banned.update(range(max_candidate_rank, logits.shape[-1]))
    if banned:
        logits[list(banned)] = -torch.inf

    if repetition_penalty and repetition_penalty > 1.0:
        for token_id in set(previous_ids):
            if torch.isfinite(logits[token_id]):
                logits[token_id] = (
                    logits[token_id] / repetition_penalty
                    if logits[token_id] > 0
                    else logits[token_id] * repetition_penalty
                )

    if not torch.isfinite(logits).any():
        logits = torch.zeros_like(logits)

    if temperature <= 0:
        return int(torch.argmax(logits).item())
    logits = logits / temperature

    if top_k and top_k > 0:
        keep = min(top_k, logits.shape[-1])
        values, indices = torch.topk(logits, keep)
        filtered = torch.full_like(logits, -torch.inf)
        filtered[indices] = values
        logits = filtered

    probs = torch.softmax(logits, dim=-1)
    if top_p and 0 < top_p < 1.0:
        sorted_probs, sorted_indices = torch.sort(probs, descending=True)
        cumulative = torch.cumsum(sorted_probs, dim=-1)
        keep_mask = cumulative <= top_p
        keep_mask[0] = True
        filtered_probs = torch.zeros_like(probs)
        filtered_probs[sorted_indices[keep_mask]] = sorted_probs[keep_mask]
        probs = filtered_probs / filtered_probs.sum()

    return int(torch.multinomial(probs, 1).item())


def generate_poetry(model, index_to_word, word_to_index, config, device, start_words=""):
    model.eval()
    target_len = 24 if config.poem_type == 5 else 32
    marks = format_marks(config.poem_type)
    punctuation_ids = {word_to_index[ch] for ch in function.PUNCTUATION if ch in word_to_index}

    result = []
    ids = []
    start_chars = [
        ch
        for ch in function._normalize_text(start_words, simplify=config.simplify_text)
        if ch not in function.PUNCTUATION and ch.strip()
    ]

    with torch.no_grad():
        for char in start_chars:
            while config.constrain_format and len(result) in marks and len(result) < target_len:
                mark = marks[len(result)]
                result.append(mark)
                ids.append(word_to_index[mark])
            if len(result) >= target_len:
                return "".join(result[:target_len])
            if char not in word_to_index:
                continue
            result.append(char)
            ids.append(word_to_index[char])

        if not ids:
            starter_ids = [word_to_index[ch] for ch in STARTER_CHARS if ch in word_to_index]
            common_ids = [
                i
                for i, ch in enumerate(index_to_word[: config.start_top_n])
                if ch not in function.PUNCTUATION
            ]
            candidates = starter_ids or common_ids or [
                i for i, ch in enumerate(index_to_word) if ch not in function.PUNCTUATION
            ]
            first_id = random.choice(candidates)
            result.append(index_to_word[first_id])
            ids.append(first_id)

        while len(result) < target_len:
            if config.constrain_format and len(result) in marks:
                mark = marks[len(result)]
                result.append(mark)
                ids.append(word_to_index[mark])
                continue

            input_ids = torch.tensor([ids], dtype=torch.long, device=device)
            output, _ = model(input_ids)
            logits = output[-1]
            banned_ids = punctuation_ids if config.constrain_format else set()
            next_id = sample_next_id(
                logits,
                ids,
                temperature=config.temperature,
                top_k=config.top_k,
                top_p=config.top_p,
                repetition_penalty=config.repetition_penalty,
                no_repeat_ngram=config.no_repeat_ngram,
                banned_ids=banned_ids,
                max_candidate_rank=config.max_candidate_rank,
            )
            result.append(index_to_word[next_id])
            ids.append(next_id)

    return "".join(result[:target_len])


def generation_metrics(model, index_to_word, word_to_index, config, device):
    samples = [
        generate_poetry(
            model,
            index_to_word,
            word_to_index,
            config,
            device,
            start_words=config.start_words if i == 0 else "",
        )
        for i in range(config.sample_count)
    ]
    return {
        "samples": samples,
        "format_accuracy": function.format_accuracy(samples, config.poem_type),
        "distinct_1": function.distinct_n(samples, 1),
        "distinct_2": function.distinct_n(samples, 2),
    }


def save_samples(path, epoch, metrics):
    lines = [
        f"epoch={epoch}",
        f"format_accuracy={metrics['format_accuracy']:.4f}",
        f"distinct_1={metrics['distinct_1']:.4f}",
        f"distinct_2={metrics['distinct_2']:.4f}",
        "",
    ]
    lines.extend(metrics["samples"])
    with open(path, "w", encoding="utf-8") as f:
        for line in lines:
            f.write(line + "\n")


def run_training(config):
    set_seed(config.seed)
    data_dir = Path(config.data_dir)
    checkpoint_dir = data_dir / "checkpoints"
    figure_dir = data_dir / "figures"
    sample_dir = data_dir / "samples"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)
    sample_dir.mkdir(parents=True, exist_ok=True)

    function.ensure_dataset(
        config.raw_dir,
        max_files=config.max_files,
        force_download=config.force_download,
        download_retries=config.download_retries,
        strict_download=config.strict_download,
    )
    function.process_1(
        config.raw_dir,
        config.data_dir,
        force=config.force_process,
        max_files=config.max_files,
        simplify=config.simplify_text,
    )

    poems = function.read_poems(data_dir / f"poem_{config.poem_type}.txt")
    if not poems:
        raise RuntimeError(f"No {config.poem_type}-character poems found.")

    word_to_index, index_to_word = function.build_vocab(poems)
    dataset = classmodel.MyDataset(function.encode_poems(poems, word_to_index))

    val_size = max(1, int(len(dataset) * config.val_ratio)) if len(dataset) > 10 else 0
    train_size = len(dataset) - val_size
    if val_size:
        generator = torch.Generator().manual_seed(config.seed)
        train_dataset, val_dataset = random_split(dataset, [train_size, val_size], generator=generator)
    else:
        train_dataset, val_dataset = dataset, None

    train_loader = DataLoader(train_dataset, batch_size=config.batch_size, shuffle=True, num_workers=0)
    val_loader = (
        DataLoader(val_dataset, batch_size=config.batch_size, shuffle=False, num_workers=0)
        if val_dataset is not None
        else None
    )

    device = function.choose_device(config.device)
    print(f"Device: {device}")
    print(f"Improved model: Attention-LSTM, heads={config.attention_heads}")
    print(f"Poems: train={train_size}, val={val_size}, vocab={len(index_to_word)}")

    model = AttentionPoemLstm(
        vocab_size=len(index_to_word),
        embedding_dim=config.embedding_dim,
        hidden_dim=config.hidden_dim,
        num_layers=config.num_layers,
        attention_heads=config.attention_heads,
        dropout=config.dropout,
        label_smoothing=config.label_smoothing,
    ).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=config.lr, weight_decay=config.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="min",
        factor=0.5,
        patience=3,
        min_lr=5e-5,
    )

    latest_checkpoint = checkpoint_dir / f"poem_{config.poem_type}_{config.run_name}_latest.pt"
    best_checkpoint = checkpoint_dir / f"poem_{config.poem_type}_{config.run_name}_best.pt"
    start_epoch = 0
    global_step = 0
    history = empty_history()
    if config.resume and latest_checkpoint.exists():
        start_epoch, global_step, history = load_checkpoint(
            latest_checkpoint, model, optimizer, device, word_to_index, index_to_word
        )
    history = normalize_history(history)
    best_val_loss = history.get("best_val_loss")
    epochs_without_improvement = int(history.get("epochs_without_improvement") or 0)

    try:
        for epoch in range(start_epoch, config.epochs):
            model.train()
            total_loss = 0.0
            total_tokens = 0

            for batch_idx, (inputs, labels) in enumerate(train_loader, start=1):
                inputs = inputs.to(device)
                labels = labels.to(device)
                optimizer.zero_grad(set_to_none=True)
                outputs, _ = model(inputs)
                flat_labels = labels.reshape(-1)
                loss = model.loss(outputs, flat_labels)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()

                global_step += 1
                total_loss += float(loss.detach().cpu()) * flat_labels.numel()
                total_tokens += flat_labels.numel()

                if config.log_interval and batch_idx % config.log_interval == 0:
                    print(
                        f"epoch {epoch + 1}/{config.epochs} "
                        f"batch {batch_idx}/{len(train_loader)} "
                        f"loss={float(loss.detach().cpu()):.4f}"
                    )

                if config.checkpoint_every_batches and global_step % config.checkpoint_every_batches == 0:
                    save_checkpoint(
                        latest_checkpoint,
                        model,
                        optimizer,
                        epoch,
                        global_step,
                        config,
                        word_to_index,
                        index_to_word,
                        history,
                    )

            train_loss = total_loss / max(1, total_tokens)
            val_stats = evaluate(model, val_loader, device, config.eval_batches) if val_loader else {
                "val_loss": 0.0,
                "perplexity": 0.0,
            }
            monitor_loss = val_stats["val_loss"] if val_loader else train_loss
            scheduler.step(monitor_loss)
            gen_stats = generation_metrics(model, index_to_word, word_to_index, config, device)

            history["train_loss"].append(train_loss)
            history["val_loss"].append(val_stats["val_loss"])
            history["perplexity"].append(val_stats["perplexity"])
            history["format_accuracy"].append(gen_stats["format_accuracy"])
            history["distinct_1"].append(gen_stats["distinct_1"])
            history["distinct_2"].append(gen_stats["distinct_2"])

            improved = best_val_loss is None or monitor_loss < best_val_loss - config.early_stopping_min_delta
            if improved:
                best_val_loss = monitor_loss
                epochs_without_improvement = 0
                history["best_val_loss"] = best_val_loss
                history["best_epoch"] = epoch + 1
                history["epochs_without_improvement"] = epochs_without_improvement
                save_checkpoint(
                    best_checkpoint,
                    model,
                    optimizer,
                    epoch + 1,
                    global_step,
                    config,
                    word_to_index,
                    index_to_word,
                    history,
                )
            else:
                epochs_without_improvement += 1
                history["best_val_loss"] = best_val_loss
                history["epochs_without_improvement"] = epochs_without_improvement

            save_samples(
                sample_dir / f"poem_{config.poem_type}_{config.run_name}_epoch_{epoch + 1:03d}.txt",
                epoch + 1,
                gen_stats,
            )
            save_checkpoint(
                latest_checkpoint,
                model,
                optimizer,
                epoch + 1,
                global_step,
                config,
                word_to_index,
                index_to_word,
                history,
            )
            save_checkpoint(
                checkpoint_dir / f"poem_{config.poem_type}_{config.run_name}_epoch_{epoch + 1:03d}.pt",
                model,
                optimizer,
                epoch + 1,
                global_step,
                config,
                word_to_index,
                index_to_word,
                history,
            )
            figure_path = function.plot_metrics(
                history,
                figure_dir / f"training_metrics_{config.poem_type}_{config.run_name}.png",
                config.poem_type,
            )
            print(
                f"epoch {epoch + 1} done: train_loss={train_loss:.4f}, "
                f"val_loss={val_stats['val_loss']:.4f}, ppl={val_stats['perplexity']:.2f}, "
                f"format={gen_stats['format_accuracy']:.2%}, "
                f"lr={optimizer.param_groups[0]['lr']:.2e}, "
                f"best_epoch={history.get('best_epoch')}, figure={figure_path}"
            )
            print("sample:", gen_stats["samples"][0])

            if (
                config.early_stopping_patience
                and epochs_without_improvement >= config.early_stopping_patience
            ):
                print(
                    f"Early stopping: validation loss did not improve for "
                    f"{epochs_without_improvement} epochs. Best epoch: {history.get('best_epoch')}"
                )
                break

    except KeyboardInterrupt:
        print("\nInterrupted. Saving improved latest checkpoint before exit ...")
        save_checkpoint(
            latest_checkpoint,
            model,
            optimizer,
            epoch,
            global_step,
            config,
            word_to_index,
            index_to_word,
            history,
        )
        raise

    print(f"Training finished. Improved latest checkpoint: {latest_checkpoint}")
    print(f"Improved best checkpoint: {best_checkpoint}")
    print(f"Metrics figure: {figure_dir / f'training_metrics_{config.poem_type}_{config.run_name}.png'}")
    return model


def parse_args():
    parser = argparse.ArgumentParser(description="Train improved Attention-LSTM Tang poem generator.")
    parser.add_argument("--run-name", default="improved_v2")
    parser.add_argument("--raw-dir", default="tangshi")
    parser.add_argument("--data-dir", default="data")
    parser.add_argument("--poem-type", type=int, choices=[5, 7], default=7)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument("--embedding-dim", type=int, default=128)
    parser.add_argument("--hidden-dim", type=int, default=384)
    parser.add_argument("--num-layers", type=int, default=2)
    parser.add_argument("--attention-heads", type=int, default=6)
    parser.add_argument("--dropout", type=float, default=0.4)
    parser.add_argument("--weight-decay", type=float, default=2e-4)
    parser.add_argument("--label-smoothing", type=float, default=0.05)
    parser.add_argument("--val-ratio", type=float, default=0.1)
    parser.add_argument("--eval-batches", type=int, default=30)
    parser.add_argument("--sample-count", type=int, default=8)
    parser.add_argument("--checkpoint-every-batches", type=int, default=200)
    parser.add_argument("--log-interval", type=int, default=60)
    parser.add_argument("--early-stopping-patience", type=int, default=8)
    parser.add_argument("--early-stopping-min-delta", type=float, default=1e-3)
    parser.add_argument("--no-simplify-text", action="store_true")
    parser.add_argument("--no-format-constraint", action="store_true")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--start-words", default="湖光秋月两相和")
    parser.add_argument("--temperature", type=float, default=0.75)
    parser.add_argument("--top-k", type=int, default=8)
    parser.add_argument("--top-p", type=float, default=0.82)
    parser.add_argument("--repetition-penalty", type=float, default=1.08)
    parser.add_argument("--no-repeat-ngram", type=int, default=3)
    parser.add_argument("--start-top-n", type=int, default=200)
    parser.add_argument("--max-candidate-rank", type=int, default=1800)
    parser.add_argument("--max-files", type=int, default=0)
    parser.add_argument("--download-retries", type=int, default=3)
    parser.add_argument("--strict-download", action="store_true")
    parser.add_argument("--force-download", action="store_true")
    parser.add_argument("--force-process", action="store_true")
    parser.add_argument("--no-resume", action="store_true")
    parser.add_argument("--quick-test", action="store_true")
    return parser.parse_args()


def main():
    args = parse_args()
    if args.quick_test:
        args.epochs = 1
        args.max_files = args.max_files or 2
        args.batch_size = min(args.batch_size, 32)
        args.hidden_dim = min(args.hidden_dim, 64)
        args.attention_heads = 4

    config = ImprovedTrainConfig(
        run_name=args.run_name,
        raw_dir=args.raw_dir,
        data_dir=args.data_dir,
        poem_type=args.poem_type,
        batch_size=args.batch_size,
        epochs=args.epochs,
        lr=args.lr,
        embedding_dim=args.embedding_dim,
        hidden_dim=args.hidden_dim,
        num_layers=args.num_layers,
        attention_heads=args.attention_heads,
        dropout=args.dropout,
        weight_decay=args.weight_decay,
        label_smoothing=args.label_smoothing,
        val_ratio=args.val_ratio,
        eval_batches=args.eval_batches,
        sample_count=args.sample_count,
        checkpoint_every_batches=args.checkpoint_every_batches,
        log_interval=args.log_interval,
        early_stopping_patience=args.early_stopping_patience,
        early_stopping_min_delta=args.early_stopping_min_delta,
        simplify_text=not args.no_simplify_text,
        constrain_format=not args.no_format_constraint,
        max_files=args.max_files,
        download_retries=args.download_retries,
        strict_download=args.strict_download,
        force_download=args.force_download,
        force_process=args.force_process,
        resume=not args.no_resume,
        device=args.device,
        seed=args.seed,
        start_words=args.start_words,
        temperature=args.temperature,
        top_k=args.top_k,
        top_p=args.top_p,
        repetition_penalty=args.repetition_penalty,
        no_repeat_ngram=args.no_repeat_ngram,
        start_top_n=args.start_top_n,
        max_candidate_rank=args.max_candidate_rank,
    )
    run_training(config)


if __name__ == "__main__":
    main()
